

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class helloservlet
 */
public class NEWhelloservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public NEWhelloservlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("user");
		ServletConfig config=getServletConfig();
		String user = config.getInitParameter("username");
		String pwd = config.getInitParameter("password");
		ServletContext context=getServletContext();
		String path=context.getInitParameter("databasePath");
		PrintWriter pw = response.getWriter();
        

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		}
		System.out.println("COnnection established");

		Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
		} catch (SQLException e2) {
			e2.printStackTrace();
		}
	
		System.out.println("Driver Loaded..!");

		Statement st=null;
		ResultSet rs=null;
		ResultSet drs =null;
		Statement std = null;


		try 
		{

			st = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
			String query = "select * from emp";
			rs=st.executeQuery(query);
			System.out.println("ALL Data in EMP");
			int i=1;
			while (rs.next()) 
			{ 
				int id = rs.getInt(1);
				String n = rs.getString(2);
				String a = rs.getString(3);
				System.out.println(id+"   "+ n+ "   " + a);
			}
		
		try {
			conn.close();
			rs.beforeFirst();
			st.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	} 
	catch (SQLException e1)
	{
		e1.printStackTrace();
	}

		
		pw.print("<h1>Welcome "+ name +" to my first web application</h1>");
        pw.print("<br> user: "+user+"<br> password "+pwd);
        pw.print(" <br>DB path "+path);
        
        pw.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
