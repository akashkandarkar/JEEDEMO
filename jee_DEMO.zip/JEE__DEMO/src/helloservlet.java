

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class helloservlet
 */
public class helloservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public helloservlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 // fetching the data from the request object
        int id = Integer.parseInt(request.getParameter("empid"));
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        PrintWriter pw = response.getWriter();
        try {
            // Step 1: Load the Driver
            Class.forName("oracle.jdbc.driver.OracleDriver");
            System.out.println("Driver loaded successfully");
            // Step 2: Get the Connection
            conn = DriverManager.getConnection(
                    "jdbc:oracle:thin:@localhost:1521:xe", "system", "system");
            System.out.println("Connection Established");
            // // Step 4: Fire Query and get the ResultSet
            String query = "select * from EMP where id=" + id;
            st = conn.createStatement();
            rs = st.executeQuery(query);
            // Step 5: Fetch the data from the ResultSet and print
            while (rs.next()) {
                int empid = rs.getInt(1);
                String n = rs.getString(2);
                String d = rs.getString(3);
                //System.out.println(empid + " : " + n + " : " + d);
                pw.print("<h1>"+empid + " : " + n + " : " + d + "</h1>");
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                st.close();
                conn.close();
                pw.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        
        //pw.close();
    }
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
